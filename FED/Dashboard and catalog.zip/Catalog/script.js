var sidebarOpen = false;
var sidebar = document.getElementById('header');

function openSidebar() {
  if (!sidebarOpen) {
    sidebar.classList.add('sidebar-resp');
    sidebarOpen = true;
  }
}

function closeSidebar() {
  if (sidebarOpen) {
    sidebar.classList.remove('sidebar-resp');
    sidebarOpen = false;
  }
}